class Ocra
  VERSION = '1.3.10'
end
